# keygen.py
from cryptography.fernet import Fernet
from pathlib import Path

def generate_key(path='secret.key'):
    key = Fernet.generate_key()
    Path(path).write_bytes(key)
    print(f"Saved key to {path}. Keep this secret!")

if __name__ == "__main__":
    generate_key()
