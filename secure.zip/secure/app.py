# app.py
import os
import sqlite3
from pathlib import Path
from datetime import datetime
from flask import Flask, request, redirect, url_for, render_template, flash, send_file, abort
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet
from dotenv import load_dotenv
import io

load_dotenv()

# config
BASE_DIR = Path(__file__).parent
UPLOAD_FOLDER = Path(os.getenv("UPLOAD_FOLDER", BASE_DIR / "uploads"))
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.getenv("DATABASE", BASE_DIR / "instance/files.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
MAX_CONTENT = int(os.getenv("MAX_CONTENT_LENGTH", 0)) or None

# get key
FERNET_KEY = os.getenv("FERNET_KEY")
if not FERNET_KEY:
    # fallback: try reading secret.key
    key_file = BASE_DIR / "secret.key"
    if key_file.exists():
        FERNET_KEY = key_file.read_bytes()
    else:
        raise RuntimeError("Encryption key not found. Set FERNET_KEY in .env or create secret.key")

f = Fernet(FERNET_KEY if isinstance(FERNET_KEY, bytes) else FERNET_KEY.encode())

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT
app.secret_key = os.urandom(24)  # used by flash only; in prod use stable secret

# DB helpers
def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            upload_time TEXT NOT NULL,
            size INTEGER NOT NULL
        );
    """)
    conn.commit()
    conn.close()

init_db()

ALLOWED_EXT = None  # optional: set of allowed extensions

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # upload
        uploaded = request.files.get("file")
        if not uploaded or uploaded.filename == '':
            flash("No file selected")
            return redirect(request.url)

        filename = secure_filename(uploaded.filename)
        # read bytes
        data = uploaded.read()
        # encrypt
        token = f.encrypt(data)
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        stored_name = f"{timestamp}_{filename}.enc"
        stored_path = UPLOAD_FOLDER / stored_name
        stored_path.write_bytes(token)

        # save metadata
        conn = get_db_conn()
        conn.execute("INSERT INTO files (original_name, stored_name, upload_time, size) VALUES (?, ?, ?, ?)",
                     (filename, stored_name, datetime.utcnow().isoformat(), len(token)))
        conn.commit()
        conn.close()

        flash(f"Uploaded and encrypted: {filename}")
        return redirect(url_for("index"))

    # GET -> list files
    conn = get_db_conn()
    files = conn.execute("SELECT * FROM files ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("index.html", files=files)

@app.route("/download/<int:file_id>")
def download(file_id):
    conn = get_db_conn()
    row = conn.execute("SELECT * FROM files WHERE id = ?", (file_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)
    stored_path = UPLOAD_FOLDER / row["stored_name"]
    if not stored_path.exists():
        abort(404)

    token = stored_path.read_bytes()
    # decrypt
    try:
        plaintext = f.decrypt(token)
    except Exception as e:
        flash("Decryption failed or file corrupted")
        return redirect(url_for("index"))

    # send as attachment
    return send_file(
        io.BytesIO(plaintext),
        as_attachment=True,
        download_name=row["original_name"]
    )

if __name__ == "__main__":
    app.run(debug=True)
